from geovpn import *
@bot.on(events.NewMessage(pattern=r"(?:.trial-ssh|/trial1)$"))
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**====================**
       **⟨  SSH Account  ⟩**
**====================**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**» pubkey:** `{PUB}`
**» Nameserver:** `{DNS}`
**====================**
**» Port OpenSSH     :** `22`
**» Port Dropbear    :** `143, 109`
**» Port SSH WS      :** `80`
**» Port SSH SSL WS  :** `443`
**» Port SSL          :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `1194`
**» Port OVPN UDP    :** `2200`
**» Port UDP Custom  :** `1-2288`
**» Proxy Squid      :** `3128, 8000`
**» BadVPN UDP       :** `7100-7300`
**◇====================◇**
**» OpenVPN      :** https://{DOMAIN}:81/
**====================**
**» Expired Until:** `{later}`
**» 🤖@tau_samawa**
**====================**
"""
			inline = [
[Button.url("[ Contact ]","t.me/tau_samawa"),
Button.url("[ Channel ]","t.me/testikuy_mang")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Acces Denied",alert=True)
