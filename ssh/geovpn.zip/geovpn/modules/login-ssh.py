from geovpn import *

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def cek_ssh(event):
	async def cek_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users ssh**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
