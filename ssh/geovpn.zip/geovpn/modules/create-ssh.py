from geovpn import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 Hari •","3"),
Button.inline("• 15 Hari •","15")],
[Button.inline("• 30 Hari •","30"),
Button.inline("• 60 Hari •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**◇====================◇**
       **  ⚡SSH Account⚡ **
**◇====================◇**
**» Host             :** `{DOMAIN}`
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**» pubkey           :** `{PUB}`
**» Nameserver       :** `{DNS}`
**◇====================◇**
**» Port OpenSSH     :** `22`
**» Port Dropbear    :** `143, 109`
**» Port SSH WS      :** `80`
**» Port SSH SSL WS  :** `443`
**» Port SSL         :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `1194`
**» Port OVPN UDP    :** `2200`
**» Port UDP Custom  :** `1-2288`
**» Proxy Squid      :** `3128, 8000`
**» BadVPN UDP       :** `7100-7300`
**◇====================◇**
**» OpenVPN Config   :** https://{DOMAIN}:81/
**◇====================◇**
**» Expired Until:** `{later}`
**» 🤖@tau_samawa**
**◇====================◇**
"""
			inline = [
[Button.url("[ Contact ]","t.me/tau_samawa"),
Button.url("[ Channel ]","t.me/testikuy_mang")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
